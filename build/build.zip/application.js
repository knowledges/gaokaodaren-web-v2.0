'use strict';

angular.module('app',['ui.router']);