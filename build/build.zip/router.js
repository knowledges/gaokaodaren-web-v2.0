'use strict';
angular.module('app').config(function($stateProvider, $urlRouterProvider){
    window.url = "/loocha";
    $urlRouterProvider.when("", "/home");
    $stateProvider
        .state("home", {//主页
            url: "/home",
            templateUrl: "html/home/home.html",
            controller:"homeCtrl",
            data: { isPublic: true},
            resolve:{
                data_province:function($q,$http,provinceURL){
                    var dtd = $q.defer();
                    $http.get(url+provinceURL).then(function (response) {
                        dtd.resolve(response);
                    }, function (response) {
                        dtd.resolve(response);
                    });
                    return dtd.promise;
                },
                data_HomeModel2:function($q,$http,men2){
                    var dtd = $q.defer();
                    $http.get(url+men2).then(function (response) {
                        dtd.resolve(response);
                    }, function (response) {
                        dtd.resolve(response);
                    });
                    return dtd.promise;
                },
                data_HomeModel3:function($q,$http,men3){
                    var dtd = $q.defer();
                    $http.get(url+men3).then(function (response) {
                        dtd.resolve(response);
                    }, function (response) {
                        dtd.resolve(response);
                    });
                    return dtd.promise;
                },
                data_HomeModel4:function($q,$http,men4){
                    var dtd = $q.defer();
                    $http.get(url+men4).then(function (response) {
                        dtd.resolve(response);
                    }, function (response) {
                        dtd.resolve(response);
                    });
                    return dtd.promise;
                },
                data_HomeModel5:function($q,$http,men5){
                    var dtd = $q.defer();
                    $http.get(url+men5).then(function (response) {
                        dtd.resolve(response);
                    }, function (response) {
                        dtd.resolve(response);
                    });
                    return dtd.promise;
                },
                data_HomeModel6:function($q,$http,men6){
                    var dtd = $q.defer();
                    $http.get(url+men6).then(function (response) {
                        dtd.resolve(response);
                    }, function (response) {
                        dtd.resolve(response);
                    });
                    return dtd.promise;
                },
                data_HomeModel7:function($q,$http,men7){
                    var dtd = $q.defer();
                    $http.get(url+men7).then(function (response) {
                        dtd.resolve(response);
                    }, function (response) {
                        dtd.resolve(response);
                    });
                    return dtd.promise;
                }
            }
        })
});